from pathlib import Path
import subprocess,zipfile,json,hashlib,shutil
root=Path('/Users/briansam-bodden/Code/java-ai/projects');work=root/'vectors-convolution-scalar-activation';out=work/'experiments/convolution-scalar-feasibility';out.mkdir(parents=True,exist_ok=True)
basejar=root/'vectors-bonsai-activation-fix/vectors-core/build/libs/vectors-core-0.1.30.jar';assert hashlib.sha256(basejar.read_bytes()).hexdigest()=='13f0bd516ede8e4306541c72ef368e94c9bddddd80a99631ff5aa65992fdbba8'
source=(work/'vectors-core/src/main/java/com/integrallis/vectors/core/PanamaVectorUtilSupport.java').read_text();start=source.index('  public void causalDepthwiseConv1dSilu(');end=source.index('\n  @Override',start);method=source[start:end]
method=method.replace('    FloatVector one = FloatVector.broadcast(ReproducibleActivationExp.FLOAT_SPECIES, 1.0f);\n','')
old='''      convolved
          .div(one.add(ReproducibleActivationExp.exp(convolved.neg())))
          .intoArray(values, valuesOffset + channel);'''
new='''      convolved.intoArray(values, valuesOffset + channel);
      scalarSiluInPlace(values, valuesOffset + channel, ReproducibleActivationExp.FLOAT_SPECIES.length());'''
assert old in method;method=method.replace(old,new)
helper='''
  // Experimental array-only scalar activation, immediately after each stored vector group.
  // Preserves the original group completion order and uses no scratch buffer.
  private static void scalarSiluInPlace(float[] values, int offset, int length) {
    for (int index = offset; index < offset + length; index++) {
      float value = values[index];
      values[index] = value / (1.0f + (float) StrictMath.exp(-value));
    }
  }
'''
javac='/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin/javac'
artifacts={'published':Path('/Users/briansam-bodden/.gradle/caches/modules-2/files-2.1/com.integrallis/vectors-core/0.1.29/9a9831f6b838978ea5cbca052e6045573f556390/vectors-core-0.1.29.jar'),'fdlibm':basejar}
for label,m in [('half-scalar',method),('full-scalar',method.replace('ReproducibleActivationExp.FLOAT_SPECIES','FLOAT_SPECIES'))]:
 folder=out/label;folder.mkdir();p=folder/'PanamaVectorUtilSupport.java';p.write_text(source[:start]+m+helper+source[end:]);classes=folder/'build';classes.mkdir()
 subprocess.run([javac,'--add-modules','jdk.incubator.vector','-cp',str(basejar),'-d',str(classes),str(p)],check=True)
 jar=classes/'candidate.jar'; changes={str(p.relative_to(classes)):p.read_bytes() for p in classes.rglob('*.class')}
 with zipfile.ZipFile(basejar) as src,zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as dst:
  for info in src.infolist():dst.writestr(info,changes.pop(info.filename,src.read(info.filename)))
  assert not changes,changes
 artifacts[label]=jar
probe=root/'vectors-exp-interval-experiment/experiments/exp-interval-feasibility/ConvolutionBoundaryProbe.java';shutil.copyfile(probe,out/probe.name)
subprocess.run([javac,'--add-modules','jdk.incubator.vector','-cp',str(basejar),'-d',str(out/'build'),str(out/probe.name)],check=True)
(out/'artifacts.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in artifacts.items()},indent=2)+'\n')
shutil.copyfile('/tmp/build-convolution-scalar-feasibility.py',out/'build-prototypes.py')
print(out)
