from pathlib import Path
import shutil,subprocess,zipfile
root=Path('/Users/briansam-bodden/Code/java-ai');stage=Path('/tmp/q5-final-v4');src=stage/'source/scalar-activation';src.mkdir(parents=True,exist_ok=True)
p=root/'projects/vectors-activation-boundary/vectors-core/src/main/java/com/integrallis/vectors/core/PanamaVectorUtilSupport.java';s=p.read_text()
a=s.index('    ReproducibleActivationExp.swiGlu(out, outOffset, gate, gateOffset, up, upOffset, length);');s=s[:a]+'''    for (int index = 0; index < length; index++) {
      float value = gate[gateOffset + index];
      out[outOffset + index] = value / (1.0f + (float) StrictMath.exp(-value)) * up[upOffset + index];
    }'''+s[a+len('    ReproducibleActivationExp.swiGlu(out, outOffset, gate, gateOffset, up, upOffset, length);'):]
a=s.index('    int historyLength = kernelSize - 1;',s.index('  public void causalDepthwiseConv1dSilu('));b=s.index('\n  @Override',a)
s=s[:a]+'''    int historyLength = kernelSize - 1;
    int vectorLimit = FLOAT_SPECIES.loopBound(channels);
    for (int channel = 0; channel < channels; channel++) {
      float input = values[valuesOffset + channel];
      float convolved = input * weights[weightsOffset + historyLength * channels + channel];
      float previous = history[historyOffset + channel];
      boolean fused = channel < vectorLimit && PanamaConstants.HAS_FAST_VECTOR_FMA;
      convolved = fused ? Math.fma(previous, weights[weightsOffset + channel], convolved)
          : convolved + previous * weights[weightsOffset + channel];
      for (int tap = 1; tap < historyLength; tap++) {
        int historyIndex = historyOffset + tap * channels + channel;
        float current = history[historyIndex];
        convolved = fused ? Math.fma(current, weights[weightsOffset + tap * channels + channel], convolved)
            : convolved + current * weights[weightsOffset + tap * channels + channel];
        history[historyIndex - channels] = current;
      }
      history[historyOffset + (historyLength - 1) * channels + channel] = input;
      values[valuesOffset + channel] = convolved / (1.0f + (float) StrictMath.exp(-convolved));
    }
  }
'''+s[b:];(src/p.name).write_text(s);classes=src/'classes';classes.mkdir(exist_ok=True);base=stage/'bonsai-proof/lib/vectors-core-0.1.30.jar';java='/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin/'
subprocess.run([java+'javac','--add-modules','jdk.incubator.vector','-cp',str(base),'-d',str(classes),str(src/p.name)],check=True)
shutil.copytree(stage/'bonsai-proof/lib',stage/'bonsai-proof/scalar-lib',dirs_exist_ok=True);target=stage/'bonsai-proof/scalar-lib/vectors-core-0.1.30.jar';tmp=target.with_suffix('.tmp')
with zipfile.ZipFile(base) as old,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as new:
 changes={str(p.relative_to(classes)):p.read_bytes() for p in classes.rglob('*.class')}
 for i in old.infolist():new.writestr(i,changes.pop(i.filename,old.read(i.filename)))
 for n,b in changes.items():new.writestr(n,b)
tmp.replace(target)
print(target)
