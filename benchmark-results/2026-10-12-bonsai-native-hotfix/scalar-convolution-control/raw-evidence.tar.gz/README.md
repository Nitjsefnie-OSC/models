# Vector convolution plus in-place scalar SiLU: rejected for warm latency

This isolated feasibility experiment keeps the vector multiply/FMA convolution and persistent-history updates, stores each convolved group into the existing values array, and immediately applies `value / (1f + (float) StrictMath.exp(-value))` through an array-only scalar helper. No new buffer, public route, warmup counter or configuration flag is added. Production PR100 and frozen cohorts are unchanged.

The primary `half-scalar` variant preserves the current vector-group width and store order. A `full-scalar` companion uses the original full float species for accumulation; per-channel arithmetic and the existing scalar-tail boundary remain identical for the disjoint buffers tested. Full-width overlapping-buffer behavior has not been qualified. Neither variant should be adopted.

## Recorded local results

Four rotating fresh-process cohorts compare actual published, current `13f0` and both experimental JARs. Each executes10240channels/kernel4,1000changing-input warmups and500measured requests, consuming outputs. Every cold and warmed output and full persistent history matches independent scalar replay preserving fused-vector/unfused-tail arithmetic. This shared macOS/x86 host is not controlled for timing; no confidence, portability or whole-model acceptance claim is made.

| Arm | Cold allocated bytes | Warm allocated bytes/call | Warm latency range |
|---|---:|---:|---:|
| Published0.1.29 |5.100–5.101MB|143360B|154–167µs|
| Current exact13f0 |21.977–21.986MB|0B|83–94µs|
| Current-width vector + scalar SiLU |4.868MB|0B|223–245µs|
| Full-width vector + scalar SiLU |4.178–4.179MB|0B|172–238µs|

The primary variant removes the local cold-allocation excess (0.9544×published,0.2215×current), but warm latency is1.464×published and2.571×current. The full-width variant is0.8192×published cold allocation but1.306×published and2.293×current warm latency. These are paired geometric ratios across four cohorts, not precision-qualified gates. The warm slowdown is observed in every candidate/current pairing. No whole-model trial is justified as an adoption attempt on these results; existing whole-model requirements remain unchanged.

Twenty fresh-JVM Bonsai activation-sequence checks pass: both candidates ×default/64/128/256/512 vector ceilings ×normal/no-FMA (both library flags and `-XX:-UseFMA`). They cover actual48-head gates,259-channel kernel4 convolution, offsets, persistent12-token history and2000cold/hot sequence repetitions against independent expected arithmetic. Requested512 selects256bits here. Actual512hardware, ARM, all floating-point bit patterns, all shapes and overlapping convolution buffers are not qualified by this study.

## Archived predecessor

`/tmp/build-scalar-activation-control.py` and `/tmp/q5-final-v4/source/scalar-activation/PanamaVectorUtilSupport.java` already contain a scalar activation control. That older control scalarizes **both** convolution accumulation (using Math.fma where the original vector lanes fused) and SwiGLU; it is a different ablation. The present candidate keeps vector convolution, changes only its final activation, and leaves SwiGLU/sigmoid/softplus unchanged. Historical scalar whole-model failures are not substituted for this experiment's observations.

`artifacts.json` identifies all executed JARs; candidate compilation uses the actual current core SHA13f0bd516ede8e4306541c72ef368e94c9bddddd80a99631ff5aa65992fdbba8. Raw commands, outputs, hashes, contract logs and source are retained. No release or production change follows from the local cold-memory improvement.
