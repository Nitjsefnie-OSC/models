from pathlib import Path
import json,subprocess,os,hashlib,platform
out=Path('/Users/briansam-bodden/Code/java-ai/projects/vectors-convolution-scalar-activation/experiments/convolution-scalar-feasibility'); artifacts=json.loads((out/'artifacts.json').read_text());java='/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin/java';slf4j=next(Path('/Users/briansam-bodden/.gradle/caches/modules-2/files-2.1/org.slf4j/slf4j-api/2.0.17').glob('*/*.jar'));rows=[]
for block in range(4):
 arms=list(artifacts);arms=arms[block:]+arms[:block]
 for arm in arms:
  cmd=[java,'--add-modules','jdk.incubator.vector','-Xms256m','-Xmx512m','-cp',os.pathsep.join([str(out/'build'),artifacts[arm]['path'],str(slf4j)]),'com.integrallis.vectors.core.ConvolutionBoundaryProbe']
  result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=65);(out/f'block{block}-{arm}.log').write_text(result.stdout); result.check_returncode(); row=json.loads(result.stdout.splitlines()[-1]);row.update(arm=arm,block=block,command=cmd);rows.append(row);(out/'convolution-raw.json').write_text(json.dumps(rows,indent=2)+'\n');print(block,arm,row['coldBytes'],row['coldNanos'],row['hotBytesPerCall'],row['hotNanosPerCall'],row['coldOracleMismatches'],row['hotOracleMismatches'],flush=True)
(out/'environment.json').write_text(json.dumps({'platform':platform.platform(),'java':subprocess.check_output([java,'-version'],stderr=subprocess.STDOUT,text=True),'scope':'local shared-host feasibility diagnostic, four rotated process cohorts; no release or whole-model claim'},indent=2)+'\n')
