from pathlib import Path
import subprocess,json,os
out=Path(__file__).resolve().parent;java='/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin/java';slf4j=next(Path('/Users/briansam-bodden/.gradle/caches/modules-2/files-2.1/org.slf4j/slf4j-api/2.0.17').glob('*/*.jar'));artifacts=json.loads((out/'artifacts.json').read_text());rows=[]
for arm in ['half-scalar','full-scalar']:
 for bits in ['default','64','128','256','512']:
  for nofma in [False,True]:
   args=[] if bits=='default' else ['-Dvectors.maxBits='+bits]
   if nofma:args+=['-Dvectors.useVectorFMA=false','-Dvectors.useScalarFMA=false','-XX:-UseFMA']
   cmd=[java,'--add-modules','jdk.incubator.vector','-Xmx256m',*args,'-cp',os.pathsep.join([str(out/'build'),artifacts[arm]['path'],str(slf4j)]),'com.integrallis.vectors.core.BonsaiActivationSequenceProbe']
   r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60);log=f'contract-{arm}-{bits}-'+('no-fma' if nofma else 'fma')+'.log';(out/log).write_text(r.stdout);row={'arm':arm,'requestedBits':bits,'noFma':nofma,'exitCode':r.returncode,'command':cmd,'log':log};rows.append(row);(out/'contract-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,bits,nofma,r.returncode,flush=True);r.check_returncode()
