package com.integrallis.vectors.core;
import java.util.SplittableRandom;
import jdk.incubator.vector.FloatVector;
public class IntervalContractProbe {
 public static void main(String[] args) {
  int target=Integer.parseInt(args[0]), lanes=ReproducibleActivationExp.FLOAT_SPECIES.length();
  float[] input=new float[lanes], output=new float[lanes]; long checked=0, mismatches=0;
  SplittableRandom random=new SplittableRandom(8731124);
  float[] special={0f,-0f,Float.NaN,Float.intBitsToFloat(0xffc00001),Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY,Float.MIN_VALUE,-Float.MIN_VALUE,Float.MIN_NORMAL,-Float.MIN_NORMAL,Float.MAX_VALUE,-Float.MAX_VALUE,-104f,-103.97208f,-87f,88f,88.72284f,89f,0x1p-25f,-0x1p-25f};
  for(int base=0;base<target;base+=lanes){
   for(int lane=0;lane<lanes;lane++){
    int n=base+lane;
    if(n<special.length*3){float x=special[(n/3)%special.length];input[lane]=n%3==0?Math.nextDown(x):n%3==1?x:Math.nextUp(x);}
    else if(n<10000){float x=(float)(((n/3)%301-150)*StrictMath.log(2));input[lane]=n%3==0?Math.nextDown(x):n%3==1?x:Math.nextUp(x);}
    else input[lane]=switch(n%3){case 0->Float.intBitsToFloat(random.nextInt());case 1->(float)random.nextDouble(-104,89);default->(float)random.nextDouble(-8,8);};
   }
   ReproducibleActivationExp.exp(FloatVector.fromArray(ReproducibleActivationExp.FLOAT_SPECIES,input,0)).intoArray(output,0);
   for(int lane=0;lane<lanes;lane++){
    float expected=(float)StrictMath.exp((double)input[lane]);
    if(Float.floatToIntBits(expected)!=Float.floatToIntBits(output[lane])){
     if(mismatches++<5)System.out.printf("MISMATCH input=%a expected=%a actual=%a%n",input[lane],expected,output[lane]);
    }
    checked++;
   }
  }
  System.out.printf("{\"requestedBits\":\"%s\",\"effectiveBits\":%d,\"expLanes\":%d,\"vectorFma\":%s,\"samples\":%d,\"mismatches\":%d}%n",System.getProperty("vectors.maxBits","default"),PanamaVectorUtilSupport.FLOAT_SPECIES.vectorBitSize(),lanes,PanamaConstants.HAS_FAST_VECTOR_FMA,checked,mismatches);
  if(mismatches!=0)throw new AssertionError("contract mismatch");
 }
}
