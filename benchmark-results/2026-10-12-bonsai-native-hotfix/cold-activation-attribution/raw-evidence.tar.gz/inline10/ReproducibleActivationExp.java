/*
 * Copyright 2025-2026 Integrallis Software, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.integrallis.vectors.core;

import jdk.incubator.vector.DoubleVector;
import jdk.incubator.vector.FloatVector;
import jdk.incubator.vector.IntVector;
import jdk.incubator.vector.LongVector;
import jdk.incubator.vector.VectorOperators;
import jdk.incubator.vector.VectorShape;
import jdk.incubator.vector.VectorSpecies;

/**
 * Experimental range-reduced double Taylor polynomial with conservative float-midpoint guards.
 * Every ambiguous or exceptional vector is recomputed with StrictMath; see PROTOCOL.md.
 */
final class ReproducibleActivationExp {
  private ReproducibleActivationExp() {}

  private static final int FULL_BITS = PanamaVectorUtilSupport.FLOAT_SPECIES.vectorBitSize();
  private static final VectorSpecies<Double> DOUBLE_SPECIES =
      VectorSpecies.of(double.class, VectorShape.forBitSize(FULL_BITS));
  static final VectorSpecies<Float> FLOAT_SPECIES =
      VectorSpecies.of(float.class, VectorShape.forBitSize(Math.max(64, FULL_BITS / 2)));
  private static final ThreadLocal<double[]> STRICT_SCRATCH =
      ThreadLocal.withInitial(() -> new double[DOUBLE_SPECIES.length()]);

  private static final VectorSpecies<Integer> INT_SPECIES = VectorSpecies.of(int.class, FLOAT_SPECIES.vectorShape());
  private static final VectorSpecies<Long> LONG_SPECIES = VectorSpecies.of(long.class, DOUBLE_SPECIES.vectorShape());
  private static final DoubleVector C0 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.0000000000000p+0);
  private static final DoubleVector C1 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.5555555555555p-3);
  private static final DoubleVector C2 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.0000000000000p-1);
  private static final DoubleVector C3 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.1111111111111p-7);
  private static final DoubleVector C4 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.5555555555555p-5);
  private static final DoubleVector C5 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.a01a01a01a01ap-13);
  private static final DoubleVector C6 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.6c16c16c16c17p-10);
  private static final DoubleVector C7 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.71de3a556c734p-19);
  private static final DoubleVector C8 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.a01a01a01a01ap-16);
  private static final DoubleVector C9 = DoubleVector.broadcast(DOUBLE_SPECIES, 0x1.27e4fb7789f5cp-22);
  private static DoubleVector polynomialExp(DoubleVector x) {
    var half = DoubleVector.broadcast(DOUBLE_SPECIES, .5).blend(-.5, x.compare(VectorOperators.LT, 0.0));
    var integers = (IntVector) x.mul(0x1.71547652b82fep0).add(half).convertShape(VectorOperators.D2I, INT_SPECIES, 0);
    var kd = (DoubleVector) integers.convertShape(VectorOperators.I2D, DOUBLE_SPECIES, 0);
    var k = (LongVector) integers.convertShape(VectorOperators.I2L, LONG_SPECIES, 0);
    var r = x.sub(kd.mul(0x1.62e42feep-1)).sub(kd.mul(0x1.a39ef35793c76p-33));
    var r2 = r.mul(r);
    var r4 = r2.mul(r2);
    var r8 = r4.mul(r4);
    var p0 = C0.fma(r, C0);
    var p1 = C1.fma(r, C2);
    var p2 = C3.fma(r, C4);
    var p3 = C5.fma(r, C6);
    var p4 = C7.fma(r, C8);
    var p5 = C9;
    var q0 = p1.fma(r2, p0);
    var q1 = p3.fma(r2, p2);
    var q2 = p5.fma(r2, p4);
    var p = q2.fma(r8, q1.fma(r4, q0));
    return p.reinterpretAsLongs().add(k.lanewise(VectorOperators.LSHL, 52)).reinterpretAsDoubles();
  }

  private static void strictExpInPlace(double[] lanes) {
    for (int lane = 0; lane < lanes.length; lane++) lanes[lane] = StrictMath.exp(lanes[lane]);
  }

  static FloatVector exp(FloatVector input) {
    if (DOUBLE_SPECIES.length() == 1) {
      return FloatVector.zero(FLOAT_SPECIES)
          .withLane(0, (float) StrictMath.exp(input.lane(0)))
          .withLane(1, (float) StrictMath.exp(input.lane(1)));
    }
    DoubleVector wide = (DoubleVector) input.convertShape(VectorOperators.F2D, DOUBLE_SPECIES, 0);
    DoubleVector result = polynomialExp(wide);
    var low = result.reinterpretAsLongs().and(0x1fffffffL);
    var ambiguous =
        low.compare(VectorOperators.GE, 0xfffc000L)
            .and(low.compare(VectorOperators.LE, 0x10004000L))
            .cast(DOUBLE_SPECIES)
            .or(wide.compare(VectorOperators.LT, -87.0))
            .or(wide.compare(VectorOperators.GT, 88.0))
            .or(wide.test(VectorOperators.IS_FINITE).not());
    if (ambiguous.anyTrue()) {
      double[] lanes = STRICT_SCRATCH.get();
      wide.intoArray(lanes, 0);
      strictExpInPlace(lanes);
      result = DoubleVector.fromArray(DOUBLE_SPECIES, lanes, 0);
    }
    return (FloatVector) result.convertShape(VectorOperators.D2F, FLOAT_SPECIES, 0);
  }

  private static final double HI = 0x1.62e42feep-1, LO = 0x1.a39ef35793c76p-33;
  /** Keeps the full vector computation behind an array-only call boundary. */
  static void swiGlu(
      float[] out,
      int outOffset,
      float[] gate,
      int gateOffset,
      float[] up,
      int upOffset,
      int length) {
    int index = 0;
    int limit = PanamaVectorUtilSupport.FLOAT_SPECIES.loopBound(length);
    FloatVector oneFloat = FloatVector.broadcast(FLOAT_SPECIES, 1.0f);
    for (; index < limit; index += FLOAT_SPECIES.length()) {
      FloatVector value = FloatVector.fromArray(FLOAT_SPECIES, gate, gateOffset + index);
      FloatVector multiplier = FloatVector.fromArray(FLOAT_SPECIES, up, upOffset + index);
      FloatVector input = value.neg();
      FloatVector result;
      if (DOUBLE_SPECIES.length() == 1) {
        result = exp(input);
      } else {
        var bounded = input.max(-104.0f).min(89.0f);
        DoubleVector x =
            (DoubleVector) bounded.convertShape(VectorOperators.F2D, DOUBLE_SPECIES, 0);
        var half =
            DoubleVector.broadcast(DOUBLE_SPECIES, .5)
                .blend(-.5, x.compare(VectorOperators.LT, 0.0));
        var integers =
            (IntVector)
                x.mul(0x1.71547652b82fep0)
                    .add(half)
                    .convertShape(VectorOperators.D2I, INT_SPECIES, 0);
        var kd = (DoubleVector) integers.convertShape(VectorOperators.I2D, DOUBLE_SPECIES, 0);
        var k = (LongVector) integers.convertShape(VectorOperators.I2L, LONG_SPECIES, 0);
        var hi = x.sub(kd.mul(HI));
        var lo = kd.mul(LO);
        var r = hi.sub(lo);
        var t = r.mul(r);
        var polynomial =
            t.mul(0x1.6376972bea4d0p-25)
                .add(-0x1.bbd41c5d26bf1p-20)
                .mul(t)
                .add(0x1.1566aaf25de2cp-14)
                .mul(t)
                .add(-0x1.6c16c16bebd93p-9)
                .mul(t)
                .add(0x1.555555555553ep-3);
        var c = r.sub(t.mul(polynomial));
        var one = DoubleVector.broadcast(DOUBLE_SPECIES, 1.0);
        var y = one.sub(lo.sub(r.mul(c).div(c.neg().add(2.0))).sub(hi));
        y = y.reinterpretAsLongs().add(k.lanewise(VectorOperators.LSHL, 52)).reinterpretAsDoubles();

        result = (FloatVector) y.convertShape(VectorOperators.D2F, FLOAT_SPECIES, 0);
        result = result.blend(Float.POSITIVE_INFINITY, input.compare(VectorOperators.GT, 89.0f));
        result = result.blend(0.0f, input.compare(VectorOperators.LT, -104.0f));
        result = result.blend(input.add(input), input.test(VectorOperators.IS_NAN));
      }
      value.div(oneFloat.add(result)).mul(multiplier).intoArray(out, outOffset + index);
    }
    for (; index < length; index++) {
      float value = gate[gateOffset + index];
      out[outOffset + index] =
          value / (1.0f + (float) StrictMath.exp(-value)) * up[upOffset + index];
    }
  }
}
