# Result: reject interval prototype; retain inline Estrin as unqualified work

The new lower/upper rounding guard passed all20million sampled/edge comparisons and every cold/hot convolution replay, but **regressed steady allocation to about245,808 bytes per call** versus zero for fdlibm and inline-Estrin10. Its cold allocation was22.60–22.73MB, compared with21.98MB fdlibm. Do not integrate it or spend an exhaustive/remote qualification run on this implementation.

The archived inline-Estrin10 control allocated zero bytes per warmed call and21.12–21.20MB cold, about3.7% less than fdlibm. Its warmed latency was lower in all three local cohorts; the measurements are noisy and shared-host, so they do not qualify latency. This variant deserves preservation as potential throughput work, but it does **not** solve the historical cold allocation gap of roughly22MB corrected versus5MB published.

The exact-arithmetic idea is credible: the documented error budget leaves more than6.5x slack. The literal guard is not shorter in the caller: it adds an extra narrowing conversion, comparison, mask and scalar lane extraction/insertion. This experiment does not prove which JIT decision causes the new warm escape; allocation proves the implementation is unsuitable as it stands.

## Why cold allocation is large

The separate JFR/MXBean diagnostic measured:

| Configuration | Initialization/priming allocation | Next full-call allocation | Classes loaded in that call |
|---|---:|---:|---:|
| Corrected fdlibm, natural |0|20,999,168B|445|
| Relevant classes/provider initialized |1,731,552B|19,271,008B|197|
| One valid vector group primed |5,868,168B|15,136,584B|0|
|1000 calls warmed |1,731,744B before warmup|816B including probe overhead|0|
| Published core, natural |0|4,126,208B|315|

Initialization is real but insufficient to explain the gap. Priming one group finishes the necessary class/lambda initialization, yet the next call allocates15.14MB with zero class loads. All30 sampled main-thread TLAB-refill stacks in that call come from Vector API operations. The captured stacks include DoubleVector binary-operation templates, conversions/reinterpretation, vector wrappers and primitive backing arrays. These are transient Java objects while the explicit double-vector operation sequence is not yet optimized away. The warmed uninstrumented changing-input probe measures zero allocation, so they are not persistent per-request buffers.

Input, weights and history arrays are allocated before the counters. No new persistent convolution buffers are created by the corrected exp helper. Caller-thread allocation also excludes native compiler memory and allocations on compilation threads: reported compiler milliseconds show JIT activity, not the source of the15MB caller allocation. The retained events are sampling evidence, not a complete heap-retention profile. JFR itself changes startup/class-loading behavior, so its21MB/4MB figures are attribution controls, not replacements for uninstrumented22MB/5MB measurements.

An array-only boundary can prevent warmed vector objects from escaping, but it does not remove the objects used by unoptimized vector operations during a first call. Reducing that startup cost needs a materially smaller exact operation sequence or improved JVM handling, with unchanged numerical semantics and actual cold/hot qualification. No warmup counter, hidden route or production workaround is introduced here.
