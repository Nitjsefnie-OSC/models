from pathlib import Path
import subprocess,zipfile,hashlib,json,shutil,re
root=Path('/Users/briansam-bodden/Code/java-ai/projects');work=root/'vectors-exp-interval-experiment';out=work/'experiments/exp-interval-feasibility';out.mkdir(parents=True,exist_ok=True)
java=Path('/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin')
basejar=root/'vectors-bf16-inline/vectors-core/build/libs/vectors-core-0.1.30.jar'
base=(work/'vectors-core/src/main/java/com/integrallis/vectors/core/ReproducibleActivationExp.java').read_text()
old=(root/'vectors-activation-fast/experiments/activation-exp/estrin-inline/degree10-ReproducibleActivationExp.java').read_text()
# Retain the current bulk SwiGLU implementation; only the exp helper used by convolution changes.
bulk=base[base.index('  /** Keeps the full vector computation'):]
inline=old[:old.rfind('}')]+ '\n  private static final double HI = 0x1.62e42feep-1, LO = 0x1.a39ef35793c76p-33;\n'+bulk
interval=inline
# The experiment is intentionally unfused, including on FMA-capable hosts.
for a,b,c in [('C0','r','C0'),('C1','r','C2'),('C3','r','C4'),('C5','r','C6'),('C7','r','C8'),('p1','r2','p0'),('p3','r2','p2'),('p5','r2','p4')]:interval=interval.replace(f'{a}.fma({b}, {c})',f'{a}.mul({b}).add({c})')
interval=interval.replace('q2.fma(r8, q1.fma(r4, q0))','q2.mul(r8).add(q1.mul(r4).add(q0))')
start=interval.index('    DoubleVector wide =',interval.index('  static FloatVector exp'))
end=interval.index('\n  /** Keeps the full vector computation',start)
interval=interval[:start]+'''    var bounded = input.max(-87.0f).min(88.0f);
    DoubleVector wide = (DoubleVector) bounded.convertShape(VectorOperators.F2D, DOUBLE_SPECIES, 0);
    DoubleVector result = polynomialExp(wide);
    var lower = (FloatVector) result.mul(1.0 - 0x1.0p-38).convertShape(VectorOperators.D2F, FLOAT_SPECIES, 0);
    var upper = (FloatVector) result.mul(1.0 + 0x1.0p-38).convertShape(VectorOperators.D2F, FLOAT_SPECIES, 0);
    var ambiguous = lower.compare(VectorOperators.NE, upper)
        .or(input.compare(VectorOperators.LT, -87.0f))
        .or(input.compare(VectorOperators.GT, 88.0f))
        .or(input.test(VectorOperators.IS_FINITE).not());
    if (ambiguous.anyTrue()) {
      // Fallback touches only ambiguous lanes. No outlined vector-valued fallback.
      for (int lane = 0; lane < FLOAT_SPECIES.length(); lane++)
        if (ambiguous.laneIsSet(lane)) lower = lower.withLane(lane, (float) StrictMath.exp(input.lane(lane)));
    }
    return lower;
  }
  private static final double HI = 0x1.62e42feep-1, LO = 0x1.a39ef35793c76p-33;
''' +interval[end:]
# Remove unused scratch/fallback from interval candidate only.
interval=re.sub(r'  private static final ThreadLocal<double\[\]> STRICT_SCRATCH =\n      ThreadLocal.withInitial\(\(\) -> new double\[DOUBLE_SPECIES.length\(\)\]\);\n','',interval)
interval=re.sub(r'  private static void strictExpInPlace\(double\[\] lanes\) \{.*?\n  \}\n','',interval,flags=re.S)
# Replace historical class-level claim with explicit experimental status.
for label,text in [('inline10',inline),('interval10',interval)]:
 text=re.sub(r'/\*\*\n \* Preserves.*?\*/','/** Experimental cold-cost probe; see PROTOCOL.md. Not production-qualified. */',text,count=1,flags=re.S)
 folder=out/label;folder.mkdir(exist_ok=True);source=folder/'ReproducibleActivationExp.java';source.write_text(text)
 subprocess.run([str(java/'javac'),'--add-modules','jdk.incubator.vector','-cp',str(basejar),'-d',str(folder/'build'),str(source)],check=True)
 with zipfile.ZipFile(basejar) as src,zipfile.ZipFile(folder/'build/candidate.jar','w',zipfile.ZIP_DEFLATED) as dst:
  for item in src.infolist():
   replacement=folder/'build'/item.filename
   dst.writestr(item,replacement.read_bytes() if replacement.is_file() else src.read(item.filename))
shutil.copyfile(root/'vectors-convolution-boundary/experiments/convolution-boundary/ConvolutionBoundaryProbe.java',out/'ConvolutionBoundaryProbe.java')
subprocess.run([str(java/'javac'),'--add-modules','jdk.incubator.vector','-cp',str(basejar),'-d',str(out/'build'),str(out/'ConvolutionBoundaryProbe.java')],check=True)
artifacts={'fdlibm':basejar,'inline10':out/'inline10/build/candidate.jar','interval10':out/'interval10/build/candidate.jar'}
(out/'artifacts.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in artifacts.items()},indent=2)+'\n')
shutil.copyfile('/tmp/create-exp-interval-probe.py',out/'build-prototypes.py')
print(out)
