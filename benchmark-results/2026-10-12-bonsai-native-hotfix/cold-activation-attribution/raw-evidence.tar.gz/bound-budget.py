"""Conservative forward-error budget, not a machine-checked real arithmetic proof."""
from decimal import Decimal as D, getcontext
from math import factorial
import json
getcontext().prec=100
u=D(2)**-53
# A node is a bound on the magnitude of its exact target and its absolute error.
def coeff(n):
 exact=D(1)/D(factorial(n)); rounded=D.from_float(1/factorial(n))
 return abs(exact),abs(exact-rounded)
def mul(a,b):
 m=a[0]*b[0]; propagated=a[0]*b[1]+b[0]*a[1]+a[1]*b[1]
 return m,propagated+u*(m+propagated)
def add(a,b):
 m=a[0]+b[0]; propagated=a[1]+b[1]
 return m,propagated+u*(m+propagated)
r=(D('.347'),D(2)**-44)
r2=mul(r,r);r4=mul(r2,r2);r8=mul(r4,r4)
pairs=[add(mul(coeff(n+1),r),coeff(n)) for n in (0,2,4,6,8)]
q0=add(mul(pairs[1],r2),pairs[0]);q1=add(mul(pairs[3],r2),pairs[2]);q2=add(mul(coeff(10),r2),pairs[4]);p=add(mul(q2,r8),add(mul(q1,r4),q0))
remainder=r[0].exp()*r[0]**11/D(factorial(11))
absolute=p[1]+remainder
relative=absolute/(-r[0]).exp()
# Interval multiplications incur <=u relative rounding; StrictMath <=1ulp adds <=2u.
chosen=D(2)**-38
assert relative+3*u < chosen/2
hi=D.from_float(float.fromhex('0x1.62e42feep-1'));lo=D.from_float(float.fromhex('0x1.a39ef35793c76p-33'))
print(json.dumps({'precisionDigits':100,'u':str(u),'assumedResidualMagnitudeBound':str(r[0]),'assumedRangeReductionAbsoluteErrorBound':str(r[1]),'ln2SplitErrorTimes150':str(abs(D(2).ln()-hi-lo)*150),'estrinEvaluationAndRangePropagationErrorBound':str(p[1]),'taylorRemainderBound':str(remainder),'combinedAbsoluteBound':str(absolute),'combinedRelativeBound':str(relative),'guardRelativeRadius':str(chosen),'guardToErrorBudgetRatio':str(chosen/(relative+3*u)),'scope':'Conservative engineering derivation. Domain/k-selection and normal exact scaling arguments are documented in PROTOCOL.md; Decimal evaluation is not an outward-rounded formal proof.'},indent=2))
