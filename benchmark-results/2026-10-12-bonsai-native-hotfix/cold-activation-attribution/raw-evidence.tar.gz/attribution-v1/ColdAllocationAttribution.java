package com.integrallis.vectors.core;
import java.lang.management.ManagementFactory;
import java.nio.file.Path;
import java.util.SplittableRandom;
import jdk.jfr.Recording;
public class ColdAllocationAttribution {
 public static void main(String[] args)throws Exception {
  String mode=args[0]; int channels=10240;
  var mx=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();mx.setThreadAllocatedMemoryEnabled(true);
  var classes=ManagementFactory.getClassLoadingMXBean();var compiler=ManagementFactory.getCompilationMXBean();
  int lanes=PanamaVectorUtilSupport.FLOAT_SPECIES.length();
  float[] values=new float[channels],history=new float[channels*3],weights=new float[channels*4];
  var random=new SplittableRandom(810753);
  for(int i=0;i<values.length;i++)values[i]=(float)random.nextDouble(-4,4);
  for(int i=0;i<history.length;i++)history[i]=(float)random.nextDouble(-1,1);
  for(int i=0;i<weights.length;i++)weights[i]=(float)random.nextDouble(-.5,.5);
  try(var rec=new Recording()) {
   rec.enable("jdk.ObjectAllocationInNewTLAB").withStackTrace();
   rec.enable("jdk.ObjectAllocationOutsideTLAB").withStackTrace();
   rec.enable("jdk.ClassLoad").withStackTrace();
   rec.enable("jdk.Compilation");
   rec.start();
   long thread=Thread.currentThread().threadId(),initBefore=mx.getThreadAllocatedBytes(thread);
   if(!mode.equals("natural")) {
    Class.forName("com.integrallis.vectors.core.ReproducibleActivationExp");
    Class.forName("com.integrallis.vectors.core.VectorUtil");
    // Empty call exercises provider/dispatch class initialization without vector arithmetic.
    VectorUtil.causalDepthwiseConv1dSilu(values,0,history,0,weights,0,0,4);
   }
   long initBytes=mx.getThreadAllocatedBytes(thread)-initBefore;
   if(mode.equals("warm"))for(int i=0;i<1000;i++)VectorUtil.causalDepthwiseConv1dSilu(values,0,history,0,weights,0,channels,4);
   long before=mx.getThreadAllocatedBytes(thread),loaded=classes.getTotalLoadedClassCount(),compile=compiler.getTotalCompilationTime();
   VectorUtil.causalDepthwiseConv1dSilu(values,0,history,0,weights,0,channels,4);
   long allocated=mx.getThreadAllocatedBytes(thread)-before;
   long loadedDelta=classes.getTotalLoadedClassCount()-loaded,compilationDelta=compiler.getTotalCompilationTime()-compile;
   rec.stop();rec.dump(Path.of(args[1]));
   System.out.printf("{\"mode\":\"%s\",\"bits\":%d,\"mainThreadId\":%d,\"preinitializeBytes\":%d,\"callBytes\":%d,\"loadedClassesDuringCall\":%d,\"compilerMillisDuringCall\":%d,\"value\":%a}%n",mode,lanes*32,thread,initBytes,allocated,loadedDelta,compilationDelta,values[13]);
  }
 }
}
