from pathlib import Path
import subprocess,os,json,collections,hashlib,shutil
out=Path('/Users/briansam-bodden/Code/java-ai/projects/vectors-exp-interval-experiment/experiments/exp-interval-feasibility');jd=Path('/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin');slf4j=next(Path('/Users/briansam-bodden/.gradle/caches/modules-2/files-2.1/org.slf4j/slf4j-api/2.0.17').glob('*/*.jar'));base=json.loads((out/'artifacts.json').read_text())['fdlibm']['path'];rows=[]
for mode in ['natural','preinitialize','one-group','warm']:
 jfr=out/f'attribution-{mode}.jfr';cmd=[str(jd/'java'),'--add-modules','jdk.incubator.vector','-Xms256m','-Xmx512m','-cp',os.pathsep.join([str(out/'build'),base,str(slf4j)]),'com.integrallis.vectors.core.ColdAllocationAttribution',mode,str(jfr)]
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=80);(out/f'attribution-{mode}.log').write_text(r.stdout);r.check_returncode();print(r.stdout,flush=True)
 raw=subprocess.check_output([str(jd/'jfr'),'print','--json','--events','jdk.ObjectAllocationInNewTLAB,jdk.ObjectAllocationOutsideTLAB',str(jfr)],text=True);data=json.loads(raw);events=data['recording']['events'];group=collections.Counter();stacks=collections.Counter();main=[]
 for event in events:
  v=event['values'];thread=v.get('eventThread',{});
  if thread.get('javaName')!='main':continue
  name=v.get('objectClass',{}).get('name','unknown');size=v.get('allocationSize',0);group[name]+=size
  frames=v.get('stackTrace',{}).get('frames',[]) if v.get('stackTrace') else []
  frames=[f["method"]["type"]["name"]+'.'+f['method']['name'] for f in frames]
  stacks[';'.join(frames[:10])]+=size; main.append(event)
 (out/f'attribution-{mode}-allocation-events.json').write_text(json.dumps(main,indent=2)+'\n')
 rows.append({'mode':mode,'command':cmd,'jfrSha256':hashlib.sha256(jfr.read_bytes()).hexdigest(),'jfrBytes':jfr.stat().st_size,'recordedMainThreadAllocationEvents':len(main),'sampledObjectAllocationBytes':sum(group.values()),'sampledBytesByClass':group.most_common(20),'sampledBytesByStack':stacks.most_common(15),'warning':'TLAB refill events sample allocating objects, not all objects or retained heap; byte sums are not a total-allocation profile. Warmup precedes recording.'})
 (out/'attribution-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
shutil.copyfile('/tmp/run-cold-attribution.py',out/'run-cold-attribution.py')
