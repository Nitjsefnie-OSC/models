from pathlib import Path
import subprocess,json,os,shutil
out=Path('/Users/briansam-bodden/Code/java-ai/projects/vectors-exp-interval-experiment/experiments/exp-interval-feasibility');java='/Users/briansam-bodden/.sdkman/candidates/java/25.0.3-tem/bin/java';slf4j=next(Path('/Users/briansam-bodden/.gradle/caches/modules-2/files-2.1/org.slf4j/slf4j-api/2.0.17').glob('*/*.jar'));rows=[]
for bits in ['default','64','128','256','512']:
 for nofma in [False,True]:
  args=[] if bits=='default' else ['-Dvectors.maxBits='+bits]
  if nofma:args+=['-Dvectors.useVectorFMA=false','-Dvectors.useScalarFMA=false','-XX:-UseFMA']
  cmd=[java,'--add-modules','jdk.incubator.vector','-Xmx256m',*args,'-cp',os.pathsep.join([str(out/'build'),str(out/'interval10/build/candidate.jar'),str(slf4j)]),'com.integrallis.vectors.core.IntervalContractProbe','2000000']
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45);log=f'contract-{bits}-'+('no-fma' if nofma else 'fma')+'.log';(out/log).write_text(r.stdout);r.check_returncode();row=json.loads(r.stdout.splitlines()[-1]);row.update(command=cmd,log=log);rows.append(row);(out/'contract-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['requestedBits'],row['effectiveBits'],nofma,row['samples'],row['mismatches'],flush=True)
shutil.copyfile('/tmp/check-exp-interval-contract.py',out/'check-contract.py');shutil.copyfile('/tmp/run-exp-interval-feasibility.py',out/'run-convolution.py')
